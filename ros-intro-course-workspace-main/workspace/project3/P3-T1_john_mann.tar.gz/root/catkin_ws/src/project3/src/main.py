#!/usr/bin/env python3
# John Mann Project 3 Task 1

from wall_follow import WallFollower

if __name__ == "__main__":
	wall_follower = WallFollower()
