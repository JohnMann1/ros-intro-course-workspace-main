#!/usr/bin/env python3
# John Mann Project 2 Task 1

from action_client import ActionClient

if __name__ == "__main__":
    print("1")
    print("2")
    simple_action_client = ActionClient()
