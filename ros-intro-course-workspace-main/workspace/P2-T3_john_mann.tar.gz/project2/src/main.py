#!/usr/bin/env python3
# John Mann Project 2 Task 3
# simple main file to run nodes (only 1 in this case)

from map_listener import FrontierExplorer

if __name__ == "__main__":
	frontier_explorer = FrontierExplorer()
