John Mann Project 2 Task 3 ReadMe

map_listener.py seems to work well up to a point. It will search for the first 2 centroids correctly and go to them, but once it runs into trouble, the navigation corrects and I can't seem to get it to listen to my goals again.

All the code is main.py and map_listener.py. to run it I use the same commands from task1 and then
	>$ rosrun project2 main.py

I still get the same warning about my numpy version being incorrect, but it hasn't caused any issues, and Weston said it was fine


