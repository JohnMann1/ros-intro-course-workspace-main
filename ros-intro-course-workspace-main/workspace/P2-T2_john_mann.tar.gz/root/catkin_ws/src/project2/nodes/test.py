#! /usr/bin/env python

import rospy

from nav_msg.msg import OccupanyGrid

if __name__ == "__main__":
	print("uhh")
